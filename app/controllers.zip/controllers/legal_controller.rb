class LegalController < ApplicationController
  def privacy
  end
end
